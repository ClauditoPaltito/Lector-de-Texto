#!/usr/bin/python
#-*- coding:utf-8 -*- 
from gtts import gTTS
import os
import docx
from PyPDF2 import PdfFileReader
import codecs

click = int(input("Ingrese un tipo de texto a leer:\n 1. Escribir mi propio texto\n 2. Leer un archivo de texto\n 3. Leer un archivo word\n 4. Leer un rechivo pdf\n "))

lenguage = "es-us"

if click == 1:
    # Crear variable la cual será un archivo de texto.
    myText1 = input("Ingrese texto: ")
    output = gTTS(text=myText1, lang=lenguage, slow=False)
    output.save("output1.mp3")
    os.system("start output1.mp3")
if click == 2:
    # Abrir un archivo de texto y leerlo en español.
    fn  = open("text.txt", "r", encoding="utf-8")
    # Cambiar todos los saltos de linea por espacios.
    myText2 = fn.read().replace("\n", " ")
    # Crear el archivo de audio 
    output = gTTS(text=myText2, lang=lenguage, slow=False)
    output.save("output2.mp3")
    fn.close()
    os.system("start output2.mp3")
if click == 3:
    doc = docx.Document("Wordtext.docx")
    CompletedText = []
    # Crear una lista por cada parrafo
    for paragraph in doc.paragraphs:
        CompletedText.append(paragraph.text)
    # Juntar cada parrafo en un archivo de texto
    myText3 = '\n'.join(CompletedText)
    # Crear audio
    output = gTTS(text=myText3, lang=lenguage, slow=False)
    output.save("output3.mp3") 
    os.system("start output3.mp3")
if click == 4:
    # El transformador de pdf a texto aún no funciona para utf-8 por lo que tiene problemas
    pdf= codecs.open("pdftest.pdf", 'rb')
    pdfreader = PdfFileReader(pdf)
    text = []
    for i in range(0, pdfreader.getNumPages()):
        text.append(pdfreader.getPage(i).extractText())
    myText4 = '\n'.join(text)
    output = gTTS(text=myText4, lang=lenguage, slow=False)
    output.save("output4.mp3")
    os.system("start output4.mp3")





